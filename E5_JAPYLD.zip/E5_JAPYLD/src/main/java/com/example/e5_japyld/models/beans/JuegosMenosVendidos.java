package com.example.e5_japyld.models.beans;

public class JuegosMenosVendidos {
    private String nombreJuego;

    public String getNombreJuego() {
        return nombreJuego;
    }

    public void setNombreJuego(String nombreJuego) {
        this.nombreJuego = nombreJuego;
    }
}
